export default interface Persona {
  email: string;
  firstName: string;
  id?: string;
  lastName: string;
}
