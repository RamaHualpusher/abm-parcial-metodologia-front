import * as React from 'react';

const Home: React.FC = () => {
  // Render
  return (
    <div>
      This is Home page!
    </div>
  );
};

export default Home;
