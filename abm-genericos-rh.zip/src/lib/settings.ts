const settings = {
  api: {
    URL: 'http://localhost:3000/api',
  },
};

export default settings;
